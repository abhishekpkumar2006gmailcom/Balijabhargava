import 'dotenv/config';
import fs from 'node:fs/promises';
import pg from 'pg';
const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const sql = await fs.readFile(new URL('../db/schema.sql', import.meta.url), 'utf8');
await pool.query(sql);
await pool.query(`INSERT INTO articles(title,slug,excerpt,body_html,category,author,status,featured,published_at) VALUES
('The Vijayanagara Empire and the Making of a Southern Capital','vijayanagara-southern-capital','A sample archival article demonstrating the central publishing system.','<p>This is sample content for the production preview. Replace it from the administrator dashboard.</p><h2>Editorial Note</h2><p>Articles are stored centrally in PostgreSQL and can include documents, images and video.</p>','Vijayanagara','Archive Editorial Board','published',true,NOW()),
('Reading Inscriptions as Historical Evidence','reading-inscriptions-historical-evidence','A sample article for epigraphy and documentary history.','<p>Use the Article Editor to replace this sample with your own research and sources.</p>','Epigraphy','Archive Editorial Board','published',false,NOW()),
('Architecture, Memory and Heritage','architecture-memory-heritage','A sample article demonstrating long-form historical reading.','<p>The public site loads articles page by page, so the archive can grow without sending the entire catalogue to every visitor.</p>','Architecture','Archive Editorial Board','published',false,NOW())
ON CONFLICT (slug) DO NOTHING`);
console.log('Database initialized.');
await pool.end();
