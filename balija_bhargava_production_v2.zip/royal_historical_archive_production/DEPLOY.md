# BALIJA BHARGAVA — Production Deployment

## 1. Server
Use a Linux VPS/cloud server with Docker, a domain and enough disk for your media. Put Caddy/Nginx/Cloudflare in front of the app for HTTPS.

## 2. Environment
Copy `.env.example` to `.env` and set:
- `POSTGRES_PASSWORD` — long random database password
- `SESSION_SECRET` — random 64+ character secret
- `VISITOR_HASH_SALT` — random secret
- `ADMIN_CODE=GuRuMaDwA#1*2/3`
- `PUBLIC_BASE_URL=https://balijabhargava.com`

Do not commit `.env` to Git.

## 3. Start
```bash
docker compose up -d --build
curl http://127.0.0.1:3000/healthz
```

## 4. HTTPS
Use the included `Caddyfile.example` and point your DNS A/AAAA records at the server. Only expose HTTPS publicly; keep PostgreSQL private.

## 5. Database
PostgreSQL is persistent. The schema includes indexed articles, media, sessions, activity logs and de-duplicated visitor view records.

## 6. Backups
Run `scripts/backup-db.sh` daily via cron/systemd and copy backups off-server. Test `scripts/restore-db.sh` on a separate database before relying on a backup.

## 7. Media
The preview supports PDF/video/image by URL or device. Production uploads are stored on the server volume. For a large archive, replace the upload volume with S3-compatible object storage + CDN before very large video growth.

## 8. Multi-device behavior
Articles, homepage settings, media records and views are stored centrally in PostgreSQL. No article/content data uses browser localStorage. Socket.IO broadcasts content changes to connected clients.

## 9. Production checklist
- [ ] Domain DNS configured
- [ ] HTTPS certificate active
- [ ] Strong DB password
- [ ] Strong session secret
- [ ] Strong visitor hash salt
- [ ] Admin code set to `GuRuMaDwA#1*2/3`
- [ ] Firewall restricts database access
- [ ] Daily off-server backups
- [ ] Restore test completed
- [ ] Upload size/storage limits reviewed
- [ ] Admin add/edit/delete tested from a second device
- [ ] PDF/video upload and playback tested
- [ ] View counts tested from multiple devices/networks
- [ ] Search/pagination tested with a large dataset
