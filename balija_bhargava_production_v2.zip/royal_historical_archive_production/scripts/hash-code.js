import bcrypt from 'bcryptjs';
const code = process.argv[2];
if (!code) { console.error('Usage: npm run hash-code -- YOUR_ADMIN_CODE'); process.exit(1); }
console.log(await bcrypt.hash(code, 12));
