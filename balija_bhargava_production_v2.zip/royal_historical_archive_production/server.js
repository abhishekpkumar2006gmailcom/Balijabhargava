import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cookieParser from 'cookie-parser';
import crypto from 'node:crypto';
import path from 'node:path';
import fs from 'node:fs';
import bcrypt from 'bcryptjs';
import pg from 'pg';
import multer from 'multer';
import mime from 'mime-types';
import sanitizeHtml from 'sanitize-html';
import { createServer } from 'node:http';
import { Server as SocketIOServer } from 'socket.io';
import rateLimit from 'express-rate-limit';

const { Pool } = pg;
const app = express();
const httpServer = createServer(app);
const io = new SocketIOServer(httpServer, { cors: { origin: false } });
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
const PORT = Number(process.env.PORT || 3000);
const uploadDir = path.resolve(process.env.UPLOAD_DIR || './uploads');
fs.mkdirSync(uploadDir, { recursive: true });

app.set('trust proxy', 1);
app.use(helmet({ crossOriginResourcePolicy: { policy: 'same-site' } }));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true, limit: '2mb' }));
app.use(cookieParser());
app.use(express.static(path.join(process.cwd(), 'public'), { maxAge: '1h' }));
app.use('/uploads', express.static(uploadDir, { maxAge: '7d', immutable: true }));

app.get('/healthz', async (_req,res)=>{ try { await pool.query('SELECT 1'); res.json({ok:true,service:'balija-bhargava'}); } catch { res.status(503).json({ok:false}); } });

const loginLimiter = rateLimit({ windowMs: 15 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false });
const writeLimiter = rateLimit({ windowMs: 60 * 1000, limit: 120, standardHeaders: true, legacyHeaders: false });

const sessionSecret = process.env.SESSION_SECRET;
if (!sessionSecret || sessionSecret.length < 32) console.warn('WARNING: SESSION_SECRET should be at least 32 characters.');
if (!process.env.ADMIN_CODE) console.warn('WARNING: ADMIN_CODE is not set.');

const cookieName = 'archive_admin';
const hashToken = token => crypto.createHash('sha256').update(token).digest('hex');
const visitorHash = req => crypto.createHash('sha256').update(`${req.ip}|${req.get('user-agent') || ''}|${process.env.VISITOR_HASH_SALT || 'change-this-salt'}`).digest('hex');
const safeSlug = title => title.toLowerCase().trim().replace(/[^a-z0-9\s-]/g,'').replace(/\s+/g,'-').replace(/-+/g,'-').slice(0,120) || `article-${Date.now()}`;
const cleanBody = html => sanitizeHtml(String(html || ''), {
  allowedTags: ['p','br','h2','h3','h4','strong','em','blockquote','ul','ol','li','a','img','figure','figcaption','video','source','hr','table','thead','tbody','tr','th','td'],
  allowedAttributes: { a:['href','target','rel'], img:['src','alt','title','loading'], video:['controls','poster','preload'], source:['src','type'] },
  allowedSchemes: ['http','https','mailto'],
  allowProtocolRelative: false
});
const validUrl = value => {
  try { const u = new URL(value); return ['http:','https:'].includes(u.protocol) ? u.toString() : null; } catch { return null; }
};
const publicArticleSelect = `SELECT id,title,slug,excerpt,body_html,category,author,cover_url,views,created_at,updated_at,published_at,featured FROM articles WHERE status='published'`;

async function log(action, articleId, detail={}) {
  await pool.query('INSERT INTO activity_log(action,article_id,detail) VALUES($1,$2,$3)', [action, articleId || null, detail]);
}

async function auth(req,res,next) {
  const token = req.cookies[cookieName];
  if (!token) return res.status(401).json({ error:'Authentication required' });
  const row = await pool.query('SELECT * FROM sessions WHERE token_hash=$1 AND expires_at>NOW()', [hashToken(token)]);
  if (!row.rowCount) return res.status(401).json({ error:'Session expired' });
  req.admin = true; next();
}

app.get('/api/site', async (_req,res) => {
  const { rows } = await pool.query("SELECT value FROM site_settings WHERE key='site'");
  res.json(rows[0]?.value || {});
});

app.get('/api/articles', async (req,res) => {
  const page = Math.max(1, Number(req.query.page || 1));
  const limit = Math.min(50, Math.max(1, Number(req.query.limit || 12)));
  const offset = (page-1)*limit;
  const q = String(req.query.q || '').trim();
  const category = String(req.query.category || '').trim();
  const params = [];
  const where = ["status='published'"];
  if (q) { params.push(`%${q}%`); where.push(`(title ILIKE $${params.length} OR excerpt ILIKE $${params.length})`); }
  if (category) { params.push(category); where.push(`category=$${params.length}`); }
  const count = await pool.query(`SELECT COUNT(*)::int AS count FROM articles WHERE ${where.join(' AND ')}`, params);
  params.push(limit, offset);
  const rows = await pool.query(`SELECT id,title,slug,excerpt,body_html,category,author,cover_url,views,created_at,updated_at,published_at,featured FROM articles WHERE ${where.join(' AND ')} ORDER BY featured DESC, published_at DESC NULLS LAST, id DESC LIMIT $${params.length-1} OFFSET $${params.length}`, params);
  res.json({ page, limit, total: count.rows[0].count, articles: rows.rows });
});

app.get('/api/articles/:slug', async (req,res) => {
  const { rows } = await pool.query(`${publicArticleSelect} AND slug=$1`, [req.params.slug]);
  if (!rows[0]) return res.status(404).json({error:'Article not found'});
  const article = rows[0];
  const media = await pool.query('SELECT id,kind,source_type,url,title,mime_type FROM article_media WHERE article_id=$1 ORDER BY id', [article.id]);
  res.json({ article, media: media.rows });
});

app.post('/api/articles/:id/view', rateLimit({ windowMs: 60 * 1000, limit: 30, standardHeaders: true, legacyHeaders: false }), async (req,res) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const article = await client.query("SELECT id,views FROM articles WHERE id=$1 AND status='published' FOR UPDATE", [req.params.id]);
    if (!article.rows[0]) { await client.query('ROLLBACK'); return res.status(404).json({error:'Article not found'}); }
    const hash = visitorHash(req);
    const inserted = await client.query('INSERT INTO article_views(article_id,visitor_hash) VALUES($1,$2) ON CONFLICT DO NOTHING RETURNING article_id', [req.params.id, hash]);
    let views = Number(article.rows[0].views);
    if (inserted.rowCount) { const updated = await client.query("UPDATE articles SET views=views+1 WHERE id=$1 RETURNING views", [req.params.id]); views = Number(updated.rows[0].views); }
    await client.query('COMMIT');
    io.emit('article:view', { id:Number(req.params.id), views });
    res.json({ views, counted: Boolean(inserted.rowCount) });
  } catch (e) { await client.query('ROLLBACK').catch(()=>{}); throw e; } finally { client.release(); }
});

app.post('/api/admin/login', loginLimiter, async (req,res) => {
  const supplied = String(req.body.code || '');
  const expected = String(process.env.ADMIN_CODE || '');
  const suppliedBuf=Buffer.from(supplied); const expectedBuf=Buffer.from(expected); const valid=expected && suppliedBuf.length===expectedBuf.length && crypto.timingSafeEqual(suppliedBuf,expectedBuf); if (!valid) return res.status(401).json({error:'Invalid administrator code'});
  const token = crypto.randomBytes(48).toString('base64url');
  await pool.query('INSERT INTO sessions(token_hash,expires_at,ip,user_agent) VALUES($1,NOW()+INTERVAL \'12 hours\',$2,$3)', [hashToken(token), req.ip, req.get('user-agent') || '']);
  res.cookie(cookieName, token, { httpOnly:true, secure:process.env.NODE_ENV==='production', sameSite:'strict', maxAge:12*60*60*1000, path:'/' });
  res.json({ok:true});
});
app.post('/api/admin/logout', auth, async (req,res) => {
  await pool.query('DELETE FROM sessions WHERE token_hash=$1',[hashToken(req.cookies[cookieName])]);
  res.clearCookie(cookieName,{path:'/'}); res.json({ok:true});
});
app.get('/api/admin/me', auth, (_req,res)=>res.json({authenticated:true}));

const storage = multer.diskStorage({
  destination: (_req,_file,cb)=>cb(null,uploadDir),
  filename: (_req,file,cb)=>cb(null, `${crypto.randomUUID()}${path.extname(file.originalname).toLowerCase()}`)
});
const maxBytes = Number(process.env.MAX_UPLOAD_MB || 512)*1024*1024;
const upload = multer({ storage, limits:{ fileSize:maxBytes }, fileFilter:(_req,file,cb)=>{
  const ok = file.mimetype === 'application/pdf' || file.mimetype.startsWith('video/') || file.mimetype.startsWith('image/');
  cb(ok ? null : new Error('Only PDF, video and image files are allowed'), ok);
}});

app.get('/api/admin/articles', auth, async (req,res) => {
  const page=Math.max(1,Number(req.query.page||1)); const limit=Math.min(100,Math.max(1,Number(req.query.limit||50))); const offset=(page-1)*limit;
  const q=String(req.query.q||'').trim(); const params=[]; let where='status <> \'trash\'';
  if(q){params.push(`%${q}%`);where=`${where} AND (title ILIKE $1 OR slug ILIKE $1)`;}
  const rows=await pool.query(`SELECT * FROM articles WHERE ${where} ORDER BY updated_at DESC LIMIT $${params.length+1} OFFSET $${params.length+2}`,[...params,limit,offset]);
  const count=await pool.query(`SELECT COUNT(*)::int count FROM articles WHERE ${where}`,params);
  res.json({page,limit,total:count.rows[0].count,articles:rows.rows});
});

app.get('/api/admin/articles/:id', auth, async (req,res) => {
  const a=await pool.query('SELECT * FROM articles WHERE id=$1',[req.params.id]); if(!a.rows[0]) return res.status(404).json({error:'Not found'});
  const m=await pool.query('SELECT * FROM article_media WHERE article_id=$1 ORDER BY id',[req.params.id]); res.json({article:a.rows[0],media:m.rows});
});

app.post('/api/admin/articles', auth, writeLimiter, async (req,res) => {
  const b=req.body; const title=String(b.title||'').trim(); if(!title) return res.status(400).json({error:'Title is required'});
  const slug=safeSlug(b.slug||title); const status=['draft','published','scheduled'].includes(b.status)?b.status:'draft';
  const publishedAt=status==='published'?new Date():null;
  const r=await pool.query(`INSERT INTO articles(title,slug,excerpt,body_html,category,author,cover_url,status,featured,scheduled_at,published_at) VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING *`,[title,slug,String(b.excerpt||''),cleanBody(b.body_html),String(b.category||'History'),String(b.author||'Archive Editorial Board'),(b.cover_url ? (validUrl(b.cover_url)||'') : ''),status,Boolean(b.featured),b.scheduled_at||null,publishedAt]);
  await log('article.created',r.rows[0].id,{title}); io.emit('content:changed',{type:'article.created',id:r.rows[0].id}); res.status(201).json(r.rows[0]);
});

app.put('/api/admin/articles/:id', auth, writeLimiter, async (req,res) => {
  const b=req.body; const title=String(b.title||'').trim(); if(!title) return res.status(400).json({error:'Title is required'});
  const status=['draft','published','scheduled','trash'].includes(b.status)?b.status:'draft';
  const old=await pool.query('SELECT * FROM articles WHERE id=$1',[req.params.id]); if(!old.rows[0]) return res.status(404).json({error:'Not found'});
  const publishedAt=status==='published'?(old.rows[0].published_at||new Date()):null;
  const r=await pool.query(`UPDATE articles SET title=$1,slug=$2,excerpt=$3,body_html=$4,category=$5,author=$6,cover_url=$7,status=$8,featured=$9,scheduled_at=$10,published_at=$11,updated_at=NOW() WHERE id=$12 RETURNING *`,[title,safeSlug(b.slug||title),String(b.excerpt||''),cleanBody(b.body_html),String(b.category||'History'),String(b.author||'Archive Editorial Board'),(b.cover_url ? (validUrl(b.cover_url)||'') : ''),status,Boolean(b.featured),b.scheduled_at||null,publishedAt,req.params.id]);
  await log('article.updated',req.params.id,{title}); io.emit('content:changed',{type:'article.updated',id:Number(req.params.id)}); res.json(r.rows[0]);
});

app.delete('/api/admin/articles/:id', auth, writeLimiter, async (req,res) => {
  const r=await pool.query("UPDATE articles SET status='trash',updated_at=NOW() WHERE id=$1 RETURNING id,title",[req.params.id]); if(!r.rows[0]) return res.status(404).json({error:'Not found'});
  await log('article.trashed',req.params.id,{title:r.rows[0].title}); io.emit('content:changed',{type:'article.trashed',id:Number(req.params.id)}); res.json({ok:true});
});
app.post('/api/admin/articles/:id/restore', auth, writeLimiter, async (req,res) => {
  const r=await pool.query("UPDATE articles SET status='draft',updated_at=NOW() WHERE id=$1 AND status='trash' RETURNING *",[req.params.id]); if(!r.rows[0]) return res.status(404).json({error:'Trash article not found'});
  await log('article.restored',req.params.id,{title:r.rows[0].title}); io.emit('content:changed',{type:'article.restored',id:Number(req.params.id)}); res.json(r.rows[0]);
});
app.delete('/api/admin/articles/:id/permanent', auth, writeLimiter, async (req,res) => {
  const media=await pool.query("SELECT url,source_type FROM article_media WHERE article_id=$1",[req.params.id]);
  const r=await pool.query('DELETE FROM articles WHERE id=$1 RETURNING id,title',[req.params.id]); if(!r.rows[0]) return res.status(404).json({error:'Not found'});
  for(const m of media.rows){ if(m.source_type==='upload' && m.url.startsWith('/uploads/')) fs.unlink(path.join(uploadDir,path.basename(m.url))).catch(()=>{}); }
  await log('article.deleted_permanently',req.params.id,{title:r.rows[0].title}); io.emit('content:changed',{type:'article.deleted_permanently',id:Number(req.params.id)}); res.json({ok:true});
});

app.post('/api/admin/articles/:id/media', auth, writeLimiter, upload.single('file'), async (req,res) => {
  let url=String(req.body.url||'').trim(); let sourceType='url'; let mimeType=String(req.body.mime_type||''); let kind=String(req.body.kind||''); let title=String(req.body.title||'').trim();
  if(req.file){ sourceType='upload'; url=`/uploads/${req.file.filename}`; mimeType=req.file.mimetype; }
  else { url=validUrl(url); if(!url) return res.status(400).json({error:'Valid HTTPS/HTTP URL required'}); }
  if(!['pdf','video','image'].includes(kind)) kind = mimeType==='application/pdf' ? 'pdf' : mimeType.startsWith('video/') ? 'video' : 'image';
  if(!['pdf','video','image'].includes(kind)) return res.status(400).json({error:'Invalid media type'});
  const a=await pool.query('SELECT id FROM articles WHERE id=$1',[req.params.id]); if(!a.rows[0]) return res.status(404).json({error:'Article not found'});
  const r=await pool.query('INSERT INTO article_media(article_id,kind,source_type,url,title,mime_type) VALUES($1,$2,$3,$4,$5,$6) RETURNING *',[req.params.id,kind,sourceType,url,title,mimeType]);
  await log('media.added',req.params.id,{mediaId:r.rows[0].id,kind}); io.emit('content:changed',{type:'media.added',id:Number(req.params.id)}); res.status(201).json(r.rows[0]);
});
app.delete('/api/admin/media/:id', auth, writeLimiter, async (req,res) => { const r=await pool.query('DELETE FROM article_media WHERE id=$1 RETURNING *',[req.params.id]); if(!r.rows[0]) return res.status(404).json({error:'Not found'}); if(r.rows[0].source_type==='upload' && r.rows[0].url.startsWith('/uploads/')) fs.unlink(path.join(uploadDir,path.basename(r.rows[0].url))).catch(()=>{}); await log('media.deleted',r.rows[0].article_id,{mediaId:r.rows[0].id}); io.emit('content:changed',{type:'media.deleted',id:r.rows[0].article_id}); res.json({ok:true}); });

app.get('/api/admin/activity', auth, async (_req,res)=>{ const r=await pool.query('SELECT * FROM activity_log ORDER BY created_at DESC LIMIT 100'); res.json(r.rows); });
app.get('/api/admin/analytics', auth, async (_req,res)=>{ const r=await pool.query(`SELECT COUNT(*) FILTER (WHERE status='published')::int published, COUNT(*) FILTER (WHERE status='draft')::int drafts, COUNT(*) FILTER (WHERE status='trash')::int trash, COALESCE(SUM(views),0)::bigint views FROM articles`); const top=await pool.query(`SELECT id,title,views FROM articles WHERE status='published' ORDER BY views DESC LIMIT 10`); res.json({summary:r.rows[0],top:top.rows}); });

app.put('/api/admin/site', auth, writeLimiter, async (req,res)=>{ const value=req.body; await pool.query(`INSERT INTO site_settings(key,value) VALUES('site',$1) ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value`,[value]); io.emit('content:changed',{type:'site.updated'}); res.json(value); });

app.get('/robots.txt', (_req,res)=>{ const base=(process.env.PUBLIC_BASE_URL || '').replace(/\/$/,''); res.type('text/plain').send(`User-agent: *\nAllow: /\nDisallow: /api/\nSitemap: ${base}/sitemap.xml\n`); });
app.get('/sitemap.xml', async (_req,res)=>{ try { const base=(process.env.PUBLIC_BASE_URL || '').replace(/\/$/,''); const {rows}=await pool.query("SELECT slug,updated_at FROM articles WHERE status='published' ORDER BY updated_at DESC"); const urls=[`${base}/`,...rows.map(r=>`${base}/articles/${encodeURIComponent(r.slug)}`)]; const xml=urls.map((u,i)=>`<url><loc>${u}</loc>${i?`<lastmod>${new Date(rows[i-1].updated_at).toISOString()}</lastmod>`:''}</url>`).join(''); res.type('application/xml').send(`<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">${xml}</urlset>`); } catch { res.status(503).type('text/plain').send('Sitemap unavailable'); } });

app.get('/{*splat}', (_req,res)=>res.sendFile(path.join(process.cwd(),'public','index.html')));

app.use((err,_req,res,_next)=>{ console.error(err); res.status(400).json({error:err.message||'Request failed'}); });

setInterval(async()=>{
  try {
    const r=await pool.query("UPDATE articles SET status='published',published_at=COALESCE(published_at,NOW()),updated_at=NOW() WHERE status='scheduled' AND scheduled_at IS NOT NULL AND scheduled_at<=NOW() RETURNING id");
    if(r.rowCount){ for(const row of r.rows){ await log('article.auto_published',row.id); io.emit('content:changed',{type:'article.auto_published',id:Number(row.id)}); } }
  } catch(e){ console.error('scheduler',e.message); }
}, 30*1000).unref();

setInterval(()=>pool.query('DELETE FROM sessions WHERE expires_at<NOW()').catch(()=>{}), 60*60*1000).unref();

httpServer.listen(PORT, ()=>console.log(`Balija Bhargava running on http://localhost:${PORT}`));
