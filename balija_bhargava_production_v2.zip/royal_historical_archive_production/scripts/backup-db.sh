#!/usr/bin/env sh
set -eu
STAMP=$(date -u +%Y%m%dT%H%M%SZ)
mkdir -p "${BACKUP_DIR:-./backups}"
pg_dump "${DATABASE_URL}" | gzip > "${BACKUP_DIR:-./backups}/balija-bhargava-${STAMP}.sql.gz"
find "${BACKUP_DIR:-./backups}" -type f -name '*.sql.gz' -mtime +14 -delete
printf 'Backup created: %s\n' "${BACKUP_DIR:-./backups}/balija-bhargava-${STAMP}.sql.gz"
