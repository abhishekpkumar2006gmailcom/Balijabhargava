#!/usr/bin/env sh
set -eu
FILE=${1:?Usage: restore-db.sh backup.sql.gz}
gunzip -c "$FILE" | psql "${DATABASE_URL}"
printf 'Restore completed from %s\n' "$FILE"
