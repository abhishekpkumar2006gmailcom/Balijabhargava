# BALIJA BHARGAVA — Production Full-Stack Archive v2

A production-oriented historical publishing platform with the same royal/formal visual language as the original preview.

## Included
- PostgreSQL central storage; no article/content localStorage
- Secure server-side admin authentication
- Administrator code configured as `GuRuMaDwA#1*2/3` via `.env`
- Article create/edit/publish/schedule/trash/delete workflow
- Server-side sanitization and URL validation
- PDF/video/image attachments from URL or device
- Persistent server uploads with a path ready for object storage/CDN migration
- De-duplicated visitor view counting with PostgreSQL
- Socket.IO content/view events
- Indexed pagination and server-side search
- Homepage/site settings persisted centrally
- Activity log
- Automated scheduled publishing worker
- Database backup/restore scripts
- HTTPS reverse-proxy example
- Responsive royal/formal public design
- Public homepage without Historical Collections and Historical Timeline sections

## Important
This repository is deployable, but you must run it on your own server and complete the deployment checklist in `DEPLOY.md`. Never publish with example secrets or without HTTPS/backups.
